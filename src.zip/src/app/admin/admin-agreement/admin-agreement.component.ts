import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agreement',
  templateUrl: './admin-agreement.component.html',
  styleUrls: ['./admin-agreement.component.scss']
})
export class AdminAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
