import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-my-profile',
  templateUrl: './client-my-profile.component.html',
  styleUrls: ['./client-my-profile.component.scss']
})
export class ClientMyProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
