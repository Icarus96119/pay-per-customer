import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-live-chat',
  templateUrl: './client-live-chat.component.html',
  styleUrls: ['./client-live-chat.component.scss']
})
export class ClientLiveChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
