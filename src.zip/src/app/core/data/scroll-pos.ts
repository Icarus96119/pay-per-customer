export const ScrollPosition = {
  Root: 'root',
  AdminPanelContainer: 'admin_panel_container',
  ClientPanelContainer: 'client_panel_container'
};
