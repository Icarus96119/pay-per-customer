import { Sms, Email } from '../models/notification';
import { normalUser } from './consts';

export const allSms: Sms[] = [
  {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }, {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }, {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }
];

export const allEmails: Email[] = [
  {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }, {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }, {
    sender: normalUser,
    receiver: normalUser,
    createdAt: 'July 16, 2020',
    content: 'Hello'
  }
];
